let products = [];
let cart = [];

let productsContainer = document.getElementById("products");
let cartContainer = document.getElementById("cart");
let cartCount = document.getElementById("cartCount");
let totalPrice = document.getElementById("totalPrice");
console.log(cartCount);


async function getProducts() {

    try {

        let response = await fetch("https://fakestoreapi.com/products");
        let data = await response.json();
        products = data;
        console.log(products);
        displayProducts();
    } catch (error) {
        console.log("Error:", error);
    }
}
function displayProducts() {
    products.forEach(function(product) {
        let productDiv = document.createElement("div");
        productDiv.className = "product";
        productDiv.innerHTML = `
            <img src="${product.image}">
            <h3>${product.title}</h3>
            <p>Price: ₹${product.price}</p>
            <button onclick="addToCart(${product.id})">Add to Cart</button>
        `;
        productsContainer.appendChild(productDiv);
    });

}
function addToCart(id){
    let product = products.find(function(item){
        return item.id === id;
    });
    cart.push(product);
    cartCount.innerText = cart.length;
    displayCart();
    let total=cart.reduce(function(sum, product){
        return sum + product.price;
    }, 0);
    totalPrice.innerText = "Total Price: ₹" + total.toFixed(2);
}
function displayCart(){
    cartContainer.innerHTML = "";
    cart.forEach(function(product){
        let cartItemDiv = document.createElement("div");
        cartItemDiv.className = "cart-item";
        cartItemDiv.innerHTML = `
            <span>${product.title}</span>
            <span>₹${product.price}</span>
            <button onclick="removeFromCart(${product.id})">Remove</button>
        `;
        cartContainer.appendChild(cartItemDiv);
    });
}
function removeFromCart(id){
    cart = cart.filter(function(product){
        return product.id !== id;
    });
    cartCount.innerText = cart.length;
    displayCart();
    let total=cart.reduce(function(sum, product){
        return sum + product.price;
    }, 0);
    totalPrice.innerText = "Total Price: ₹" + total.toFixed(2);
}
getProducts();